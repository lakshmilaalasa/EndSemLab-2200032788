package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class DemoController {

    private List<Customer> customers = new ArrayList<>();

    // Demo 1: Return an integer
    @GetMapping("/demo1")
    public int demo1() {
        return 100;
    }

    // Demo 2: Return a double
    @GetMapping("/demo2")
    public double demo2() {
        return 99.99;
    }

    // Demo 3: Return a formatted HTML string
    @GetMapping("/demo3")
    public String demo3() {
        return "<h1>Welcome to Spring Boot MVC!</h1>";
    }

    // Demo 4: Return a concatenated string
    @GetMapping("/demo4")
    public String demo4() {
        String university = "KLEF";
        return "I Study at " + university;
    }

    // Demo 5: Accept a path variable
    @GetMapping("/demo5/{id}")
    public String demo5(@PathVariable("id") int id) {
        return "Received ID: " + id;
    }

    // Demo 6: Accept two path variables and return their sum
    @GetMapping("/demo6/{a}/{b}")
    public String demo6(@PathVariable("a") int a, @PathVariable("b") int b) {
        return "Sum: " + (a + b);
    }
    @GetMapping("/demo11/{a}/{b}")
    public String demo11(@PathVariable("a") int a, @PathVariable("b") int b) {
        return "Mul: " + (a * b);
    }

    // Demo 7: Accept a request parameter
    @GetMapping("/demo7")
    public String demo7(@RequestParam("id") String id) {
        return "Received ID: " + id;
    }

    // Demo 8: Accept a path variable and return it as a string
    @GetMapping("/demo8/{name}")
    public String demo8(@PathVariable("name") String name) {
        return "Hello, " + name + "!";
    }

    // Demo 9: Add a customer (POST)
    @PostMapping("/addcustomer")
    public String addCustomer(@RequestBody Customer customer) {
        customers.add(customer);
        return "Customer Added Successfully";
    }

    // Demo 10: View all customers
    @GetMapping("/viewcustomer")
    public List<Customer> viewCustomer() {
        return customers;
    }
}
